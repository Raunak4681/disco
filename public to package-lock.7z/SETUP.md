# Setting Up the Radar Visualization Application

## Prerequisites

1. Node.js (v18 or higher)
2. Angular CLI
3. Java Development Kit (JDK) 17 or higher
4. Maven

## Step-by-Step Setup Guide

### 1. Clone the Repository

```bash
git clone <repository-url>
cd radar-visualization-app
```

### 2. Frontend Setup

1. Install Angular CLI globally:
```bash
npm install -g @angular/cli
```

2. Install project dependencies:
```bash
npm install
```

3. Create environment file:
- Copy `.env.production` to create a new `.env` file
- Update any environment-specific variables if needed

### 3. Backend Setup

1. Install Maven dependencies:
```bash
mvn clean install
```

2. Configure application properties:
- Navigate to `src/main/resources`
- Copy `application.properties` to create `application-dev.properties`
- Update database and other configurations as needed

### 4. Running the Application

1. Start the backend server:
```bash
mvn spring-boot:run
```

2. Start the frontend development server:
```bash
ng serve
```

3. Access the application:
- Open your browser and navigate to `http://localhost:4200`
- The backend API will be available at `http://localhost:8080`

## Common Issues and Solutions

1. Port Conflicts:
- If port 4200 is in use, use `ng serve --port <alternative-port>`
- If port 8080 is in use, modify the port in `application.properties`

2. Database Connection:
- Ensure your database credentials in `application.properties` are correct
- Verify the database server is running

## Production Deployment

1. Build the frontend:
```bash
ng build --prod
```

2. Build the backend:
```bash
mvn clean package
```

3. The production-ready artifacts will be available in:
- Frontend: `dist/` directory
- Backend: `target/` directory

## Support

For additional help or troubleshooting:
1. Check the project documentation
2. Review the project_analysis.md file
3. Contact the development team

Note: Make sure to replace `<repository-url>` with the actual repository URL where the code is hosted.