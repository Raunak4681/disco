import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-radar-form',
  templateUrl: './radar-form.component.html',
  styleUrls: ['./radar-form.component.css'],
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule]
})
export class RadarFormComponent implements OnInit {
  @Output() radarParamsChange = new EventEmitter<any>();
  @Output() goToLocationEvent = new EventEmitter<{latitude: number, longitude: number}>();

  radarForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.radarForm = this.fb.group({
      latitude: [51.5074, [Validators.required, Validators.min(-90), Validators.max(90)]],
      longitude: [-0.1278, [Validators.required, Validators.min(-180), Validators.max(180)]],
      height: [30, [Validators.required, Validators.min(0)]],
      range: [50, [Validators.required, Validators.min(0)]]
    });
  }

  ngOnInit(): void {
    // Emit initial values
    this.radarParamsChange.emit(this.radarForm.value);
    
    this.radarForm.valueChanges.subscribe(value => {
      if (this.radarForm.valid) {
        this.radarParamsChange.emit(value);
      }
    });
  }

  onSubmit(): void {
    if (this.radarForm.valid) {
      this.radarParamsChange.emit(this.radarForm.value);
    }
  }

  goToLocation(): void {
    if (this.radarForm.valid) {
      const { latitude, longitude } = this.radarForm.value;
      this.goToLocationEvent.emit({ latitude, longitude });
    }
  }
}