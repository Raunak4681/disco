# Offline Setup Guide for Radar Visualization Application

## Prerequisites

1. Source system with:
   - All dependencies already downloaded
   - Application running successfully
   - Internet access (for initial setup)

2. Target system with:
   - Node.js (v18 or higher)
   - Angular CLI
   - Java Development Kit (JDK) 17 or higher
   - Maven

## Step 1: Prepare Frontend Dependencies

1. On the source system:
   - Locate the `node_modules` directory in the project root
   - Copy the entire `node_modules` directory
   - Copy the following files:
     - package.json
     - package-lock.json
     - angular.json
     - tsconfig.json
     - .env.production
     - All source files from `src` directory

2. On the target system:
   - Create a new directory for the project
   - Paste all copied files maintaining the same directory structure
   - Ensure `node_modules` is placed in the project root

## Step 2: Prepare Backend Dependencies

1. On the source system:
   - Locate Maven local repository (typically in `~/.m2/repository`)
   - Copy the following:
     - The entire `.m2/repository` directory
     - pom.xml file
     - All Java source files from `src/main` directory
     - Configuration files from `src/main/resources`

2. On the target system:
   - Place the `.m2/repository` directory in the user's home directory
   - Create project directory structure matching the source
   - Copy all Java source files and resources maintaining structure

## Step 3: Configure Application

1. Frontend Configuration:
   
     API_URL=http://localhost:8080
     WEBSOCKET_URL=ws://localhost:8080/ws
     ```

2. Backend Configuration:
   - Copy `application.properties` to `application-dev.properties`
   - Update database configuration if needed
   - Ensure all paths are relative or point to valid locations

## Step 4: Build and Run

1. Build Frontend:
   ```bash
   ng build
   ```

2. Build Backend:
   ```bash
   mvn clean package
   ```

3. Start the Application:
   - Start backend:
     ```bash
     mvn spring-boot:run
     ```
   - Start frontend:
     ```bash
     ng serve
     ```

4. Verify Access:
   - Frontend: http://localhost:4200
   - Backend API: http://localhost:8080

## Troubleshooting

1. Missing Dependencies:
   - Verify all node_modules are copied correctly
   - Check Maven repository contains all required JARs

2. Configuration Issues:
   - Ensure all path references are valid
   - Verify environment variables are set correctly

3. Build Errors:
   - Check Java and Node.js versions match requirements
   - Verify all source files were copied completely

## Notes

- Keep the directory structure identical to source system
- Ensure file permissions are set correctly after copying
- Test the application thoroughly after setup
- Document any system-specific configurations made