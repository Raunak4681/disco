angular.module('radarApp')
    .controller('RadarCoverageController', ['$scope', 'radarService', 'webSocketService', function($scope, radarService, webSocketService) {
        // Function to calculate terrain-aware coverage points
        async function calculateTerrainAwarePoints(center, range) {
            const points = [];
            const numPoints = 360; // One point per degree for smooth coverage
            const terrainResolution = 90; // Terrain sampling resolution in meters
            
            for (let i = 0; i < numPoints; i++) {
                const angle = (i * 2 * Math.PI) / numPoints;
                let currentRange = range * 1000; // Convert range to meters
                
                // Sample terrain elevation along the radial line
                for (let r = 0; r <= currentRange; r += terrainResolution) {
                    const [x, y] = ol.proj.transform(
                        [center[0] + r * Math.cos(angle), center[1] + r * Math.sin(angle)],
                        'EPSG:3857', 'EPSG:4326'
                    );
                    
                    try {
                        // Get terrain elevation and check line of sight
                        const response = await $http.get(`${API_URL}/elevation/line-of-sight`, {
                            params: {
                                startLon: center[0],
                                startLat: center[1],
                                endLon: x,
                                endLat: y,
                                radarHeight: 30,
                                samples: 10
                            }
                        });
                        
                        if (response.data.blocked) { // Line of sight is blocked
                            currentRange = r;
                            break;
                        }
                    } catch (error) {
                        console.error('Error checking line of sight:', error);
                        // Continue with current range if API fails
                        continue;
                    }
                }
                
                // Add point at the final range for this angle
                const [x, y] = ol.proj.transform(
                    [center[0] + currentRange * Math.cos(angle), center[1] + currentRange * Math.sin(angle)],
                    'EPSG:3857', 'EPSG:4326'
                );
                points.push([x, y]);
            }
            
            // Close the polygon
            points.push(points[0]);
            return points;
        }
        
        // Get terrain elevation at a point using the elevation API
        function getTerrainElevation(point) {
            const [lon, lat] = ol.proj.transform(point, 'EPSG:3857', 'EPSG:4326');
            return $http.get(`${API_URL}/elevation?lon=${lon}&lat=${lat}`)
                .then(response => response.data.elevation)
                .catch(() => 0); // Fallback to 0 if API fails
        }
        
        // Get radar height from radar configuration
        function getRadarHeight(point) {
            const [lon, lat] = ol.proj.transform(point, 'EPSG:3857', 'EPSG:4326');
            return $http.get(`${API_URL}/radar/height?lon=${lon}&lat=${lat}`)
                .then(response => response.data.height)
                .catch(() => 30); // Fallback to 30m if API fails
        }
        
        // Check if line of sight is blocked by terrain using elevation profile
        async function isLineOfSightBlocked(start, end, startHeight, endElevation) {
            const [startLon, startLat] = ol.proj.transform(start, 'EPSG:3857', 'EPSG:4326');
            const [endLon, endLat] = ol.proj.transform(end, 'EPSG:3857', 'EPSG:4326');
            
            try {
                const response = await $http.get(`${API_URL}/elevation/profile`, {
                    params: {
                        startLon, startLat,
                        endLon, endLat,
                        samples: 10 // Number of samples along the path
                    }
                });
                
                const profile = response.data;
                const distance = ol.sphere.getDistance([startLon, startLat], [endLon, endLat]);
                
                // Check each point along the path
                return profile.some((elevation, index) => {
                    const fraction = index / (profile.length - 1);
                    const expectedHeight = startHeight + (fraction * (endElevation - startHeight));
                    const terrainHeight = elevation;
                    
                    // Calculate if terrain blocks line of sight
                    return terrainHeight > expectedHeight;
                });
            } catch (error) {
                console.error('Error checking line of sight:', error);
                return false; // Fallback to unblocked if API fails
            }
        }
        
        // Layer for managing multiple radar coverages
        const coverageLayer = new ol.layer.Vector({
            source: new ol.source.Vector(),
            style: function(feature) {
                return new ol.style.Style({
                    fill: new ol.style.Fill({
                        color: feature.get('selected') ? 'rgba(255, 0, 0, 0.4)' : 'rgba(255, 0, 0, 0.2)'
                    }),
                    stroke: new ol.style.Stroke({
                        color: feature.get('selected') ? '#ff0000' : '#ff6666',
                        width: feature.get('selected') ? 3 : 2
                    })
                });
            }
        });

        // Initialize coverage features map
        const coverageFeatures = new Map();

        // Function to update single radar coverage
        async function updateRadarCoverage(radar) {
            // Create a terrain-aware coverage polygon
            const center = ol.proj.fromLonLat([radar.longitude, radar.latitude]);
            const points = await calculateTerrainAwarePoints(center, radar.range);
            
            // Create a feature from the calculated points
            const feature = new ol.Feature({
                geometry: new ol.geom.Polygon([points])
            });

            // Set radar properties on feature
            feature.setProperties({
                radarId: radar.id,
                name: radar.name,
                selected: false
            });

            // Store or update feature
            if (coverageFeatures.has(radar.id)) {
                coverageLayer.getSource().removeFeature(coverageFeatures.get(radar.id));
            }
            coverageFeatures.set(radar.id, feature);
            coverageLayer.getSource().addFeature(feature);
        }

        // Function to update all radar coverages
        async function updateAllRadarCoverages() {
            const radars = await radarService.getRadarData();
            coverageLayer.getSource().clear();
            coverageFeatures.clear();
            await Promise.all(radars.map(updateRadarCoverage));
        }

        // Function to highlight selected radar coverage
        function selectRadarCoverage(radarId) {
            coverageFeatures.forEach(function(feature) {
                feature.set('selected', feature.get('radarId') === radarId);
            });
        }

        // Initialize coverage layer
        $scope.initializeCoverageLayer = function(map) {
            map.addLayer(coverageLayer);
            updateAllRadarCoverages();

            // Add click interaction
            map.on('click', function(event) {
                const feature = map.forEachFeatureAtPixel(event.pixel, function(feature) {
                    return feature;
                });

                if (feature) {
                    const radarId = feature.get('radarId');
                    selectRadarCoverage(radarId);
                    $scope.$emit('radarSelected', radarId);
                }
            });
        };

        // Initialize WebSocket connection
        webSocketService.connect();

        // Handle WebSocket events
        $scope.$on('radarUpdate', function(event, radar) {
            updateRadarCoverage(radar);
        });

        $scope.$on('radarDelete', function(event, radarId) {
            if (coverageFeatures.has(radarId)) {
                coverageLayer.getSource().removeFeature(coverageFeatures.get(radarId));
                coverageFeatures.delete(radarId);
            }
        });

        // Cleanup WebSocket connection when controller is destroyed
        $scope.$on('$destroy', function() {
            webSocketService.disconnect();
        });
    }]);