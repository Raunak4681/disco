import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Geometry } from 'ol/geom';
import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import ImageLayer from 'ol/layer/Image';
import Static from 'ol/source/ImageStatic';
import TileWMS from 'ol/source/TileWMS';
import { Circle as CircleStyle, Fill, Stroke, Style } from 'ol/style';
import { Vector as VectorLayer } from 'ol/layer';
import { Vector as VectorSource } from 'ol/source';
import Feature from 'ol/Feature';
import Point from 'ol/geom/Point';
import { fromLonLat } from 'ol/proj';
import { defaults as defaultControls } from 'ol/control';
import GeoJSON from 'ol/format/GeoJSON';
import { environment } from '../../environments/environment';
import { Draw, Modify } from 'ol/interaction';
import { DrawEvent } from 'ol/interaction/Draw';
import { Polygon, Circle } from 'ol/geom';

@Component({
  selector: 'app-map',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit, OnDestroy {
  private isDrawModeActive = false;
  constructor(private http: HttpClient) {}
  private map!: Map;
  private vectorLayer!: VectorLayer<VectorSource>;
  private vectorSource!: VectorSource;
  private cartodemLayer!: TileLayer<TileWMS>;
  private draw: any;
  private selectedPolygon: Feature<Polygon> | null = null;
  
  // Radar parameters
  radarParams = {
    latitude: 28.6139,
    longitude: 77.2090,
    radius: 50, // km
    elevation: 30, // meters
    tilt: 0 // degrees
  };

  ngOnInit() {
    this.initializeMap();
    this.initializeVectorLayer();
    this.updateRadarCoverage();
  }

  ngOnDestroy() {
    if (this.map) {
      this.map.dispose();
    }
  }

  private initializeMap() {
    this.cartodemLayer = new TileLayer({
      source: new TileWMS({
        url: 'http://localhost:8080/geoserver/cartodem/wms',
        params: {
          'LAYERS': 'cartodem:elevation',
          'VERSION': '1.1.0',
          'FORMAT': 'image/png',
          'TILED': true
        },
        serverType: 'geoserver',
        projection: 'EPSG:4326'
      }),
      visible: false
    });

    this.map = new Map({
      target: 'map',
      layers: [
        new TileLayer({
          source: new TileWMS({
            url: 'http://localhost:8080/geoserver/ne/wms',
            params: {
              'LAYERS': 'ne:NE1_HR_LC_SR_W_DR',
              'VERSION': '1.1.0',
              'FORMAT': 'image/png',
              'TILED': true
            },
            serverType: 'geoserver',
            projection: 'EPSG:4326'
          })
        }),
        new TileLayer({
          source: new TileWMS({
            url: 'http://localhost:8080/geoserver/radar/wms',
            params: {
              'LAYERS': 'radar:elevation',
              'VERSION': '1.1.0',
              'FORMAT': 'image/png',
              'TILED': true
            },
            serverType: 'geoserver',
            projection: 'EPSG:4326'
          })
        }),
        new ImageLayer({
          source: new Static({
            url: 'assets/elevation.tif',
            imageExtent: [-180, -90, 180, 90],
            projection: 'EPSG:4326'
          }),
          opacity: 0.6,
          visible: true
        })
      ],
      controls: defaultControls({
        attribution: true,
        zoom: true,
      }),
      view: new View({
        center: fromLonLat([this.radarParams.longitude, this.radarParams.latitude]),
        zoom: 8
      })
    });
  }

  private initializeVectorLayer() {
    this.vectorSource = new VectorSource();
    this.vectorLayer = new VectorLayer({
      source: this.vectorSource,
      style: new Style({
        image: new CircleStyle({
          radius: 8,
          fill: new Fill({ color: '#FF4444' }),
          stroke: new Stroke({ color: 'white', width: 2 })
        })
      })
    });
    this.map.addLayer(this.vectorLayer);
  }

  private updateRadarCoverage() {
    if (!this.vectorSource) {
      console.warn('Vector source not initialized');
      return;
    }

    this.vectorSource.clear();
    this.cartodemLayer.setVisible(true);
    
    this.addRadarPointAndCoverage();
    this.fetchTerrainAwareCoverage();
  }

  private addRadarPointAndCoverage() {
    // Add radar point with custom style
    const radarPoint = new Feature({
      geometry: new Point(fromLonLat([this.radarParams.longitude, this.radarParams.latitude]))
    });
    
    const radarPointStyle = new Style({
      image: new CircleStyle({
        radius: 8,
        fill: new Fill({ color: '#FF4444' }),
        stroke: new Stroke({ color: 'white', width: 2 })
      })
    });
    radarPoint.setStyle(radarPointStyle);
    
    // Create a circle for radar coverage with gradient effect
    const circleRadius = this.radarParams.radius * 1000; // Convert km to meters
    const circleGeom = new Circle(
      fromLonLat([this.radarParams.longitude, this.radarParams.latitude]),
      circleRadius
    );

    const coverageFeature = new Feature({
      geometry: circleGeom
    });

    // Create a more sophisticated coverage style with gradient
    const coverageStyle = new Style({
      fill: new Fill({
        color: 'rgba(255, 68, 68, 0.1)'
      }),
      stroke: new Stroke({
        color: '#FF4444',
        width: 3,
        lineDash: [10, 5]
      })
    });

    coverageFeature.setStyle(coverageStyle);
    
    // Add inner circle for stronger signal representation
    const innerCircleStyle = new Style({
      fill: new Fill({
        color: 'rgba(255, 68, 68, 0.3)'
      }),
      stroke: new Stroke({
        color: '#FF4444',
        width: 2
      })
    });

    const innerCircleGeom = new Circle(
      fromLonLat([this.radarParams.longitude, this.radarParams.latitude]),
      circleRadius * 0.5
    );

    const innerCircleFeature = new Feature({
      geometry: innerCircleGeom
    });

    innerCircleFeature.setStyle(innerCircleStyle);
    
    // Add all features to the source
    this.vectorSource.addFeature(radarPoint);
    this.vectorSource.addFeature(coverageFeature);
    this.vectorSource.addFeature(innerCircleFeature);
  }

  private fetchTerrainAwareCoverage() {
    this.http.get(`${environment.apiUrl}/radar/coverage`, {
      params: {
        longitude: this.radarParams.longitude.toString(),
        latitude: this.radarParams.latitude.toString(),
        range: this.radarParams.radius.toString(),
        elevation: this.radarParams.elevation.toString(),
        tilt: this.radarParams.tilt.toString()
      },
      responseType: 'json'
    }).subscribe({
      next: (coverage: any) => {
        try {
          const format = new GeoJSON();
          const terrainCoverageFeature = format.readFeature(coverage, {
            featureProjection: 'EPSG:3857'
          });
          
          if (terrainCoverageFeature instanceof Feature) {
            const terrainCoverageStyle = new Style({
              fill: new Fill({
                color: 'rgba(255, 68, 68, 0.2)'
              }),
              stroke: new Stroke({
                color: '#FF4444',
                width: 2,
                lineDash: [5, 5]
              })
            });

            terrainCoverageFeature.setStyle(terrainCoverageStyle);
            this.vectorSource.addFeature(terrainCoverageFeature);
          }
        } catch (error) {
          console.error('Error processing terrain coverage data:', error);
        }
      },
      error: (error: Error) => {
        console.error('Error fetching terrain-aware radar coverage:', error);
      }
    });
  }

  public goToLocation(): void {
    if (!this.map) return;

    this.map.getView().animate({
      center: fromLonLat([this.radarParams.longitude, this.radarParams.latitude]),
      duration: 1000,
      zoom: 12
    });

    this.updateRadarCoverage();
  }

  public onParamsChange(): void {
    this.updateRadarCoverage();
  }

  private initializeDrawTools() {
    this.draw = new Draw({
      source: this.vectorSource,
      type: 'Polygon'
    });

    this.draw.on('drawend', (event: DrawEvent) => {
      if (this.selectedPolygon) {
        this.vectorSource.removeFeature(this.selectedPolygon);
      }
      this.selectedPolygon = event.feature as Feature<Polygon>;
      this.cartodemLayer.setVisible(true);
      this.updateElevationData();
    });

    this.map.addInteraction(this.draw);
  }

  private updateElevationData() {
    if (this.selectedPolygon) {
      const extent = this.selectedPolygon.getGeometry()!.getExtent();
      // Update the Cartosat DEM layer extent
      this.cartodemLayer.getSource()?.updateParams({
        'BBOX': extent.join(','),
        'SRS': 'EPSG:4326'
      });
    }
  }

  toggleDrawMode() {
    this.isDrawModeActive = !this.isDrawModeActive;
    if (this.isDrawModeActive) {
      this.map.addInteraction(this.draw);
    } else {
      this.map.removeInteraction(this.draw);
    }
  }
}