package com.radar.controller;

import com.radar.service.TiffElevationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/elevation")
public class TiffElevationController {
    private final TiffElevationService tiffElevationService;

    @Autowired
    public TiffElevationController(TiffElevationService tiffElevationService) {
        this.tiffElevationService = tiffElevationService;
    }

    @PostMapping("/load")
    public ResponseEntity<String> loadTiffFile(@RequestParam("path") String tiffPath) {
        try {
            tiffElevationService.loadTiffFile(tiffPath);
            return ResponseEntity.ok("TIFF file loaded successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error loading TIFF file: " + e.getMessage());
        }
    }

    @GetMapping("/query")
    public ResponseEntity<?> getElevation(
            @RequestParam("longitude") double longitude,
            @RequestParam("latitude") double latitude) {
        try {
            if (!tiffElevationService.isWithinCoverage(longitude, latitude)) {
                return ResponseEntity.badRequest().body("Location is outside TIFF coverage area");
            }
            double elevation = tiffElevationService.getElevation(longitude, latitude);
            return ResponseEntity.ok(elevation);
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body("No TIFF file loaded");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error querying elevation: " + e.getMessage());
        }
    }
}