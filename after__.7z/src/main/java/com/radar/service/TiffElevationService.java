package com.radar.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.geotools.coverage.grid.GridCoverage2D;
import org.geotools.gce.geotiff.GeoTiffReader;
import org.geotools.geometry.DirectPosition2D;
import org.opengis.geometry.DirectPosition;
import org.opengis.coverage.Coverage;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import java.io.File;
import java.io.IOException;

@Service
public class TiffElevationService {
    private final ResourceLoader resourceLoader;
    private GridCoverage2D coverage;

    @Autowired
    public TiffElevationService(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    public void loadTiffFile(String tiffPath) throws IOException {
        Resource resource = resourceLoader.getResource(tiffPath);
        File file = resource.getFile();
        GeoTiffReader reader = new GeoTiffReader(file);
        coverage = (GridCoverage2D) reader.read(null);
    }

    public double getElevation(double longitude, double latitude) {
        if (coverage == null) {
            throw new IllegalStateException("No TIFF file loaded");
        }

        try {
            DirectPosition position = new DirectPosition2D(longitude, latitude);
            double[] result = new double[1];
            coverage.evaluate(position, result);
            return result[0];
        } catch (Exception e) {
            throw new RuntimeException("Error getting elevation from TIFF: " + e.getMessage(), e);
        }
    }

    public boolean isWithinCoverage(double longitude, double latitude) {
        if (coverage == null) {
            return false;
        }
        return coverage.getEnvelope2D().contains(longitude, latitude);
    }

    public void close() {
        if (coverage != null) {
            coverage.dispose();
            coverage = null;
        }
    }
}