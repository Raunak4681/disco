package com.radar.service;

import org.springframework.stereotype.Component;
import java.util.List;
import java.util.ArrayList;

@Component
public class TerrainComplexityCalculator {
    private final TiffElevationService tiffElevationService;
    private static final int SAMPLE_POINTS = 16; // Number of points to sample for complexity
    
    public TerrainComplexityCalculator(TiffElevationService tiffElevationService) {
        this.tiffElevationService = tiffElevationService;
    }
    
    public double calculateTerrainComplexity(double centerLon, double centerLat, double range) {
        List<Double> elevations = new ArrayList<>();
        double maxVariation = 0.0;
        
        // Sample points in a circular pattern
        for (int i = 0; i < SAMPLE_POINTS; i++) {
            double angle = Math.toRadians(i * (360.0 / SAMPLE_POINTS));
            double dx = range * Math.cos(angle);
            double dy = range * Math.sin(angle);
            
            double pointLon = centerLon + (dx / (111320 * Math.cos(Math.toRadians(centerLat))));
            double pointLat = centerLat + (dy / 110540);
            
            if (tiffElevationService.isWithinCoverage(pointLon, pointLat)) {
                double elevation = tiffElevationService.getElevation(pointLon, pointLat);
                elevations.add(elevation);
            }
        }
        
        // Calculate elevation variations
        if (elevations.size() > 1) {
            double baseElevation = elevations.get(0);
            for (double elevation : elevations) {
                double variation = Math.abs(elevation - baseElevation);
                maxVariation = Math.max(maxVariation, variation);
            }
        }
        
        // Normalize complexity score (0.0 - 1.0)
        return Math.min(maxVariation / 1000.0, 1.0); // Assume 1000m variation is maximum complexity
    }
    
    public void addSmoothingPoints(List<Coordinate> coordinates, 
                                  Coordinate start, 
                                  Coordinate end, 
                                  double radarLon, 
                                  double radarLat, 
                                  double radarHeight, 
                                  double tiltAngle) {
        int numPoints = 5; // Number of intermediate points
        
        for (int i = 0; i <= numPoints; i++) {
            double ratio = i / (double)numPoints;
            double lon = start.x + (end.x - start.x) * ratio;
            double lat = start.y + (end.y - start.y) * ratio;
            
            // Verify visibility of intermediate point
            if (tiffElevationService.isWithinCoverage(lon, lat)) {
                double elevation = tiffElevationService.getElevation(lon, lat);
                boolean visible = isPointVisible(radarLon, radarLat, radarHeight,
                                               lon, lat, elevation, tiltAngle);
                if (visible) {
                    coordinates.add(new Coordinate(lon, lat));
                }
            }
        }
    }
}