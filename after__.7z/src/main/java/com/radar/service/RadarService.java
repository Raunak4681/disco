package com.radar.service;

import com.radar.model.Radar;
import com.radar.repository.RadarRepository;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.PrecisionModel;
import org.locationtech.jts.io.WKTWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RadarService {
    private final RadarRepository radarRepository;
    private final TerrainService terrainService;
    private final GeometryFactory geometryFactory;
    private final WKTWriter wktWriter;
    private final WebSocketService webSocketService;

    @Autowired
    public RadarService(RadarRepository radarRepository, TerrainService terrainService, WebSocketService webSocketService) {
        this.radarRepository = radarRepository;
        this.terrainService = terrainService;
        this.webSocketService = webSocketService;
        this.geometryFactory = new GeometryFactory(new PrecisionModel(), 4326);
        this.wktWriter = new WKTWriter();
    }

    @Transactional(readOnly = true)
    public List<Radar> getAllRadars() {
        return radarRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Radar getRadarById(Long id) {
        return radarRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Radar not found with id: " + id));
    }

    @Transactional
    public Radar createRadar(Radar radar) {
        // Calculate the radar coverage considering elevation
        Geometry coverage = calculateRadarCoverage(radar.getLongitude(), radar.getLatitude(), radar.getRange());
        radar.setCoverage(coverage);
        Radar savedRadar = radarRepository.save(radar);
        webSocketService.broadcastRadarUpdate(savedRadar);
        return savedRadar;
    }

    private Geometry calculateRadarCoverage(double longitude, double latitude, double range) {
        // Calculate terrain-aware radar coverage using TerrainService
        return terrainService.calculateTerrainAwareRadarCoverage(latitude, longitude, range);
    }

    @Transactional
    public Radar updateRadar(Long id, Radar radarDetails) {
        Radar radar = getRadarById(id);
        radar.setName(radarDetails.getName());
        radar.setLatitude(radarDetails.getLatitude());
        radar.setLongitude(radarDetails.getLongitude());
        radar.setRange(radarDetails.getRange());
        radar.setCoverage(radarDetails.getCoverage());
        return radarRepository.save(radar);
    }

    @Transactional
    public void deleteRadar(Long id) {
        radarRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Radar> findRadarsInRange(double longitude, double latitude, double distance) {
        return radarRepository.findRadarsInRange(longitude, latitude, distance);
    }

    @Transactional(readOnly = true)
    public List<Radar> findRadarsIntersectingArea(Geometry area) {
        return radarRepository.findRadarsIntersectingArea(area);
    }

    public String convertGeometryToWKT(Geometry geometry) {
        return wktWriter.write(geometry);
    }
}