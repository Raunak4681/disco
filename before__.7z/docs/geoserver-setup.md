# GeoServer Setup Guide

## Overview
This guide details the configuration of GeoServer to serve elevation data from PostGIS for the radar application.

## Prerequisites
- GeoServer installed and running on port 8080
- PostGIS database with elevation_data table

## Configuration Steps

### 1. Create Workspace
1. Log into GeoServer admin interface (http://localhost:8080/geoserver/web)
2. Create a new workspace named 'radar'
3. Enable WMS services

### 2. Configure PostGIS Data Store
1. Add new PostGIS data store
2. Basic settings:
   - Data Source Name: radar_elevation
   - Database: your_database_name
   - Schema: public
   - Host: localhost
   - Port: 5432
   - User: your_database_user
   - Password: your_database_password

### 3. Publish Elevation Layer
1. Add new layer from 'radar_elevation' store
2. Select elevation_data table
3. Configure layer settings:
   - Name: elevation
   - Title: Radar Elevation Data
   - Native SRS: EPSG:4326
   - Declared SRS: EPSG:4326
   - SRS Handling: Force declared

### 4. Style Configuration
1. Create new style for elevation data
2. Use SLD to style the raster data appropriately
3. Apply style to the elevation layer

### 5. Cache Settings
1. Enable GeoWebCache for the layer
2. Configure cache formats:
   - image/png
   - image/jpeg
3. Set appropriate tile dimensions

### 6. Security
1. Set appropriate authentication for the workspace
2. Configure CORS if needed

## Testing
Verify the layer is accessible at:
http://localhost:8080/geoserver/radar/wms?service=WMS&version=1.1.0&request=GetMap&layers=radar:elevation

## Integration
Update the map component's WMS configuration to use the new layer:

```typescript
new TileLayer({
  source: new TileWMS({
    url: 'http://localhost:8080/geoserver/radar/wms',
    params: {
      'LAYERS': 'radar:elevation',
      'VERSION': '1.1.0',
      'FORMAT': 'image/png',
      'TILED': true
    },
    serverType: 'geoserver',
    projection: 'EPSG:4326'
  })
})
```