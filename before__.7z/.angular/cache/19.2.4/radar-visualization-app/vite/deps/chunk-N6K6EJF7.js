import {
  Image_default as Image_default2,
  defaultImageLoadFunction
} from "./chunk-WBQGTNEQ.js";
import {
  Image_default,
  decode
} from "./chunk-RHAKYTYM.js";
import {
  get,
  getHeight,
  getWidth,
  intersects
} from "./chunk-THK7ZGPJ.js";
import {
  EventType_default
} from "./chunk-EQCSSUQ7.js";

// node_modules/ol/source/static.js
function createLoader(options) {
  const load = options.load || decode;
  const extent = options.imageExtent;
  const crossOrigin = options.crossOrigin ?? null;
  return () => {
    const image = new Image();
    image.crossOrigin = crossOrigin;
    return load(image, options.url).then((image2) => {
      const resolutionX = getWidth(extent) / image2.width;
      const resolutionY = getHeight(extent) / image2.height;
      const resolution = resolutionX !== resolutionY ? [resolutionX, resolutionY] : resolutionY;
      return {
        image: image2,
        extent,
        resolution,
        pixelRatio: 1
      };
    });
  };
}

// node_modules/ol/source/ImageStatic.js
var Static = class extends Image_default2 {
  /**
   * @param {Options} options ImageStatic options.
   */
  constructor(options) {
    const crossOrigin = options.crossOrigin !== void 0 ? options.crossOrigin : null;
    const imageLoadFunction = options.imageLoadFunction !== void 0 ? options.imageLoadFunction : defaultImageLoadFunction;
    super({
      attributions: options.attributions,
      interpolate: options.interpolate,
      projection: get(options.projection)
    });
    this.url_ = options.url;
    this.imageExtent_ = options.imageExtent;
    this.image = null;
    this.image = new Image_default(this.imageExtent_, void 0, 1, createLoader({
      url: options.url,
      imageExtent: options.imageExtent,
      crossOrigin,
      load: (image, src) => {
        this.image.setImage(image);
        imageLoadFunction(this.image, src);
        return decode(image);
      }
    }));
    this.image.addEventListener(EventType_default.CHANGE, this.handleImageChange.bind(this));
  }
  /**
   * Returns the image extent
   * @return {import("../extent.js").Extent} image extent.
   * @api
   */
  getImageExtent() {
    return this.imageExtent_;
  }
  /**
   * @param {import("../extent.js").Extent} extent Extent.
   * @param {number} resolution Resolution.
   * @param {number} pixelRatio Pixel ratio.
   * @param {import("../proj/Projection.js").default} projection Projection.
   * @return {import("../Image.js").default} Single image.
   * @override
   */
  getImageInternal(extent, resolution, pixelRatio, projection) {
    if (intersects(extent, this.image.getExtent())) {
      return this.image;
    }
    return null;
  }
  /**
   * Return the URL used for this image source.
   * @return {string} URL.
   * @api
   */
  getUrl() {
    return this.url_;
  }
};
var ImageStatic_default = Static;

export {
  createLoader,
  ImageStatic_default
};
//# sourceMappingURL=chunk-N6K6EJF7.js.map
