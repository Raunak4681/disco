import {
  Feature_default,
  createStyleFunction
} from "./chunk-PU74ZWOL.js";
import "./chunk-KKOTSO6X.js";
import "./chunk-VNWMKJWE.js";
import "./chunk-4MWRP73S.js";
export {
  createStyleFunction,
  Feature_default as default
};
//# sourceMappingURL=ol_Feature.js.map
